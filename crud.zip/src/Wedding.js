import React from 'react'
import { Router,Switch,Route } from 'react-router-dom'
import WeddingDecoration from './WeddingDecoration'
import 'bootstrap/dist/css/bootstrap.min.css';
// import Navwedding from './Navwedding';

export default function Wedding() {
  return (
      <>
      <WeddingDecoration />
    <Router>

    <div className='App'>
    
    <Switch>
    <Route exact path='/weddingdecoration' component={WeddingDecoration}/>
    
    </Switch>
        
    </div>
    </Router>
    </>
  )
}
