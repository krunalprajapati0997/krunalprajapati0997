import React, { Component } from 'react'


export class WeddingDecoration extends Component {
  render() {
    return (
        <>
      <div>WeddingDecoration</div>
        </>
    )
  }
}

export default WeddingDecoration