import React from 'react'

export default function Events() {
  return (
    <div>Events</div>
  )
}
