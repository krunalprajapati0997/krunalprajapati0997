import React from 'react'

export default function Gallery() {
  return (
    <div>Gallery</div>
  )
}
