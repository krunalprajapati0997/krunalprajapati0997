import React from 'react'
import {Nav,Navbar,Button,Container,Form,FormControl,NavDropdown} from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css';


function Nav1() {
  return (
      <>
    <div>
        <Navbar bg="light" variant="light" expand="lg">
    <Container fluid>
      
      <Navbar.Toggle aria-controls="navbarScroll" />
      <Navbar.Collapse id="navbarScroll">
        <Nav
          className="me-auto my-2 my-lg-0"
          style={{ maxHeight: '100px' }}
          navbarScroll
        >
          <Nav.Link href="/">Home</Nav.Link>
          <Nav.Link href="/about">About</Nav.Link>
          
         
          <NavDropdown title="Wedding" id="navbarScrollingDropdown">
          <NavDropdown.Item href="weddingDecoration">Wedding Decoration</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Gate Decoration</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Mandap Decoration</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Doli Decoration</NavDropdown.Item>
         </NavDropdown>


          
          <NavDropdown title="Party" id="navbarScrollingDropdown">
          <NavDropdown.Item href="#action3">Birthday Party</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Kitty Party</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Game Party</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Club Party</NavDropdown.Item>
         </NavDropdown>


          
          <NavDropdown title="Events" id="navbarScrollingDropdown">
          <NavDropdown.Item href="#action3">Corporate Meetings And Conferences</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Corporate Retreats</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Parties And Customer Appreciations Events</NavDropdown.Item>
            </NavDropdown>

          
          <NavDropdown title="Festivals" id="navbarScrollingDropdown">
          <NavDropdown.Item href="#action3">New Year's Day</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Makar Sankranti</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Republic Day</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Maha Shivratri</NavDropdown.Item>
         </NavDropdown>

          <Nav.Link href="/gallery">Gallery</Nav.Link>
          <Nav.Link href="/contact">Contact</Nav.Link>
          
          </Nav>
        <Form className="d-flex">
          <FormControl
            type="search"
            placeholder="Search"
            className="me-2"
            aria-label="Search"
          />
          <Button variant="outline-success">Search</Button>
        </Form>
      </Navbar.Collapse>
    </Container>
  </Navbar>
  </div>
  </>
  )
}
export default Nav1
