import React from 'react'

export default function Contact() {
  return (
      <>
      contact us
    </>
  )
}

