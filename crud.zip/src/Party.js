import React from 'react'

export default function Party() {
  return (
    <div>Party</div>
  )
}

