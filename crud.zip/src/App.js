import logo from './logo.svg';
import './App.css';
import Nav1 from './Nav1';
import Home from './Home';
import About from './About';
import Wedding from './Wedding';
import Party from './Party';
import Events from './Events';
import Festivals from './Festivals';
import Gallery from './Gallery';
import Contact from './Contact';

import {BrowserRouter as Router,Route,Switch} from 'react-router-dom';

function App() {
  return (

    <Router>
    <div className="App">
    <Nav1 />
    <Switch >
     <Route exact path='/' component={Home}/>
     <Route exact path='/about' component={About}/>
    <Route exact path='/wedding' component={Wedding}/>
    <Route exact path='/party' component={Party}/>
     <Route exact path='/events' component={Events}/>
     <Route exact path='/festivals' component={Festivals}/>
     <Route exact path='/gallery' component={Gallery}/>
     <Route exact path='/contact' component={Contact}/>
    </Switch>
    </div>
    </Router>
  );
}

export default App;
