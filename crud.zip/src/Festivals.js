import React from 'react'

export default function Festivals() {
  return (
    <div>Festivals</div>
  )
}

